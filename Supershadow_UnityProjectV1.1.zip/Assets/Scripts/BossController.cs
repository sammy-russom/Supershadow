using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class BossController : MonoBehaviour
{
    public AudioSource fireSound;
    public Text healthText;
    public int id;
    public int health;
    public GameObject shootPrefab;
    public float shootForce;
    private Animator anim;
    private Transform player;
    public float vision;
    private bool playerVisible = false;
    private bool isDead = false;
    private SpriteRenderer sr;
    private int dir = -1;

    PlayerController pc;

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        sr = GetComponent<SpriteRenderer>();
        pc = FindObjectOfType<PlayerController>();
        player = GameObject.FindGameObjectWithTag("Player").transform;
        healthText.text = "Boss Health: " + health.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        //checking if player is visible
        playerVisible = (Mathf.Abs(Vector2.Distance(transform.position, player.position)) < vision);
        if (!isDead)
        {
            anim.SetBool("playerVisible", playerVisible);

            //face player
            if (transform.position.x - player.position.x < 0)
            {
                dir = 1;
                transform.eulerAngles = new Vector3(0, 180, 0);
            }
            else
            {
                dir = -1;
                transform.eulerAngles = new Vector3(0, 0, 0);
            }

            //showing boss health text
            if (playerVisible)
                healthText.gameObject.SetActive(true);
            else
                healthText.gameObject.SetActive(false);
        }
    }

    public void Shoot()
    {
        //creating bullet and shooting it
        fireSound.Play();
        GameObject newShoot = Instantiate(shootPrefab, transform.position, Quaternion.identity);
        newShoot.GetComponent<Rigidbody2D>().AddForce(new Vector3(dir, 0, 0) * shootForce, ForceMode2D.Impulse);
        Destroy(newShoot, 5);
    }

    IEnumerator Flash()
    {
        //flash when hit
        sr.color = Color.gray;
        yield return new WaitForSeconds(0.1f);
        sr.color = Color.white;
    }

    IEnumerator Die()
    {
        //when dead
        healthText.gameObject.SetActive(false);
        pc.EnemyDie();
        GetComponent<Collider2D>().enabled = false;
        isDead = true;
        anim.SetTrigger("die");
        pc.enemiesKilled++;

        yield return null;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //check collision with player attack
        if (collision.CompareTag("Attack"))
        {
            StartCoroutine(Flash());

            int s = 200;
            health -= (int)((s/500f) * 20f);
            healthText.text = "Boss Health: " + health.ToString();

            if (health <= 0)
            {
                StartCoroutine(Die());
            }
        }
    }
}
