using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public float speed;
    public Transform handPos;
    public Transform groundCheckPos;
    private Rigidbody2D rb;
    private int dir;
    private bool isTouching;
    private bool isOnGround;
    public LayerMask whatIsGround;
    public bool isDead = false;
    PlayerController pc;

    // Start is called before the first frame update
    void Start()
    {
        pc = FindObjectOfType<PlayerController>();
        rb = GetComponent<Rigidbody2D>();
        dir = Random.Range(0, 2) * 2 - 1;
    }

    // Update is called once per frame
    void Update()
    {
        //check if on ground or touching wall
        isTouching = Physics2D.OverlapCircle(handPos.position, 0.1f, whatIsGround);
        isOnGround = Physics2D.OverlapCircle(groundCheckPos.position, 0.1f, whatIsGround);

        //flip direction
        if (isTouching || !isOnGround)
        {
            if (!isDead)
            {
                if (dir == 1)
                {
                    dir = -1;
                }
                else if (dir == -1)
                {
                    dir = 1;
                }
            } 
        }
        if (dir > 0)
        {
            transform.eulerAngles = new Vector3(0, 0, 0);
        }
        else if (dir < 0)
        {
            transform.eulerAngles = new Vector3(0, 180, 0);
        }

        //move
        if (!isDead)
            rb.velocity = new Vector2(dir * speed, rb.velocity.y);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //check collision with player attack
        if (collision.CompareTag("Attack"))
        {
            pc.EnemyDie();
            isDead = true;
            rb.gravityScale = 0;
            rb.velocity = Vector2.zero;
            GetComponent<Collider2D>().enabled = false;
            foreach (Collider2D col in transform.GetComponentsInChildren<Collider2D>())
            {
                col.enabled = false;
            }
            GetComponent<Animator>().SetTrigger("die");
            Destroy(this.gameObject, 1f);
        }
    }

    private void OnDestroy()
    {
        pc.enemiesKilled++;
    }
}
