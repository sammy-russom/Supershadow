using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public AudioSource jumpSound;
    public AudioSource hitSound;
    public AudioSource enemyHitSound;
    public AudioSource swooshSound;
    public AudioSource attackSound;
    public GameObject attack;

    private SpriteRenderer sr;
    private Rigidbody2D rb;
    private Animator anim;
    private Collider2D col;

    public float speed;
    public float jumpForce;
    private float moveInput;

    private bool isGrounded;
    public Transform feetPos;
    public float checkRadius;
    public LayerMask whatIsGround;

    public Slider healthBar;
    public int maxHealth;
    public Image pauseButton;
    public Sprite[] pauseImages;
    public GameObject pauseCanvas;
    public GameObject gameOverPanel;

    private float jumpTimeCounter;
    public float jumpTime;
    private bool isJumping;

    private bool gameOver = false;
    private bool attacking = false;
    private bool isInvincible = false;
    private Coroutine invincibleCoroutine;

    public int totalEnemies;
    public int enemiesKilled;

    // Start is called before the first frame update
    void Start()
    {
        Application.targetFrameRate = 60;
        Time.timeScale = 1;
        GameObject.FindGameObjectWithTag("Music").GetComponent<AudioSource>().mute = false;

        totalEnemies = GameObject.FindGameObjectsWithTag("Enemy").Length;

        healthBar.maxValue = maxHealth;
        healthBar.value = maxHealth;

        sr = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<Collider2D>();
        anim = GetComponent<Animator>();
        attack.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (gameOver)
            return;

        //check if on ground
        isGrounded = Physics2D.OverlapCircle(feetPos.position, checkRadius, whatIsGround);

        //flipping direction based on movement
        if (moveInput > 0)
        {
            transform.eulerAngles = new Vector3(0, 0, 0);
        }
        else if (moveInput < 0)
        {
            transform.eulerAngles = new Vector3(0, 180, 0);
        }

        //jump
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Jump();
        }
        if (Input.GetKey(KeyCode.Space))
        {
            Jumping();
        }
        if (Input.GetKeyUp(KeyCode.Space))
        {
            isJumping = false;
        }

        //attack
        if (Input.GetKeyDown(KeyCode.E))
        {
            Attack();
        }

        //die if fallen down
        if (transform.position.y < -8)
        {
            Die(true);
        }

        //setting animator parameters
        anim.SetBool("isJumping", isJumping);
        anim.SetBool("isGrounded", isGrounded);
        anim.SetFloat("yVel", rb.velocity.y);
    }

    void FixedUpdate()
    {
        if (gameOver)
            return;

        //movement
        moveInput = Input.GetAxisRaw("Horizontal");
        anim.SetFloat("speed", Mathf.Abs(moveInput));
        rb.velocity = new Vector2(moveInput * speed, rb.velocity.y);
    }

    public void Jump()
    {
        //jump if on ground and not already jumping
        if (isGrounded && !isJumping)
        {
            isJumping = true;
            jumpSound.Play();
            jumpTimeCounter = jumpTime;
            rb.velocity = Vector2.up * jumpForce;
        }
    }

    public void Jumping()
    {
        if (isJumping)
        {
            if (jumpTimeCounter > 0)
            {
                rb.velocity = Vector2.up * jumpForce;
                jumpTimeCounter -= Time.deltaTime;
            }
            else
            {
                isJumping = false;
            }
        }
    }

    public void ReleaseJump()
    {
        isJumping = false;
    }

    public void Attack()
    {
        if (attacking || !isGrounded)
            return;

        StartCoroutine(AttackCoroutine());
    }

    IEnumerator AttackCoroutine()
    {
        //attack
        attacking = true;
        attack.SetActive(true);
        swooshSound.Play();
        float ogSpeed = speed;
        speed /= 2;
        int rand = Random.Range(0, 2);
        if (rand == 0)
            anim.SetTrigger("attack");
        else
            anim.SetTrigger("attack2");
        yield return new WaitForSeconds(0.4f);
        attacking = false;
        attack.SetActive(false);
        speed = ogSpeed;
    }

    private void GetHit()
    {
        if (isInvincible)
            return;

        //get hit
        enemyHitSound.Play();
        healthBar.value -= 20;
        StartCoroutine("Invincible");
        if (healthBar.value <= 0)
            Die(false);
    }

    private void Die(bool fall)
    {
        //die
        healthBar.value = 0;
        GameObject.FindGameObjectWithTag("Music").GetComponent<AudioSource>().mute = true;
        col.enabled = false;
        gameOver = true;
        rb.velocity = Vector2.zero;
        rb.gravityScale = 0;
        anim.SetTrigger("die");
        Time.timeScale = 0;
        StartCoroutine(GameOver());
    }

    IEnumerator Invincible()
    {
        //flashing when hit
        isInvincible = true;
        for (int i=0; i<6; i++)
        {
            sr.color = Color.gray;
            yield return new WaitForSeconds(0.1f);
            sr.color = Color.white;
            yield return new WaitForSeconds(0.1f);
        }
        isInvincible = false;
    }

    IEnumerator GameOver()
    {
        gameOverPanel.SetActive(true);
        //restart scene
        yield return new WaitForSecondsRealtime(2);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    void KillEnemy(Collider2D collision)
    {
        //when enemy killed 
        enemyHitSound.Play();
        rb.velocity = Vector2.up * jumpForce;
        collision.enabled = false;
        GameObject enemy = collision.gameObject.transform.parent.gameObject;
        enemy.GetComponent<Collider2D>().enabled = false;
        var enemyRb = enemy.GetComponent<Rigidbody2D>();
        enemyRb.gravityScale = 0;
        enemyRb.velocity = Vector2.zero;
        enemy.GetComponent<EnemyController>().speed = 0;
        enemy.GetComponent<EnemyController>().isDead = true;
        enemy.GetComponent<Animator>().SetTrigger("die");
        Destroy(enemy, 1);
    }

    public void EnemyDie()
    {
        //play enemy killing sfx
        attackSound.Play();
        hitSound.Play();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //collisions
        if (collision.tag == "Enemy")
        {
            GetHit();
        }
        else if (collision.tag == "Stomp")
        {
            KillEnemy(collision);
        }
        else if (collision.tag == "Win")
        {
            if (enemiesKilled >= totalEnemies)
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex+1);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //get hit if touching enemy
        if (collision.gameObject.tag == "Enemy")
        {
            GetHit();
        }
    }

    public void ExitToMenu()
    {
        //go to menu
        SceneManager.LoadScene(0);
    }

    public void PauseGame()
    {
        if (Time.timeScale == 1)
        {
            Time.timeScale = 0;
            pauseButton.sprite = pauseImages[1];
            pauseCanvas.SetActive(true);
        }
        else
        {
            Time.timeScale = 1;
            pauseButton.sprite = pauseImages[0];
            pauseCanvas.SetActive(false);
        }
    }
}
